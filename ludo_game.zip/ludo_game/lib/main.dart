import 'package:flutter/material.dart';
import 'dart:math';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Ludo Dice Game',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: LudoGameScreen(),
    );
  }
}

class LudoGameScreen extends StatefulWidget {
  @override
  _LudoGameScreenState createState() => _LudoGameScreenState();
}

class _LudoGameScreenState extends State<LudoGameScreen> {
  final int totalRounds = 10; // Set the number of rounds
  int currentRound = 1;
  int currentPlayer = 0; // Current player index (0, 1, 2, 3 for 4 players)
  final List<int> playerScores = [0, 0, 0, 0]; // Track each player's score
  final Random random = Random();
  int diceRoll = 1; // Variable to store the dice roll value

  // Function to roll the dice
  void rollDice() {
    setState(() {
      diceRoll = random.nextInt(6) + 1; // Generates a random number between 1 and 6
      playerScores[currentPlayer] += diceRoll; // Update current player's score

      currentPlayer = (currentPlayer + 1) % 4; // Move to next player

      if (currentPlayer == 0) {
        currentRound++; // Increment round if all players had their turn
      }

      if (currentRound > totalRounds) {
        showWinner(); // Check if the game is over
      }
    });
  }

  // Function to display the winner
  void showWinner() {
    int maxScore = playerScores.reduce(max);
    List<int> winners = [];

    for (int i = 0; i < playerScores.length; i++) {
      if (playerScores[i] == maxScore) {
        winners.add(i + 1);
      }
    }

    String winnerMessage = winners.length == 1
        ? 'Player ${winners[0]} wins with $maxScore points!'
        : 'It\'s a tie between Players ${winners.join(", ")} with $maxScore points!';

    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text('Game Over'),
          content: Text(winnerMessage),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
                resetGame();
              },
              child: Text('Restart'),
            ),
          ],
        );
      },
    );
  }

  // Function to reset the game
  void resetGame() {
    setState(() {
      currentRound = 1;
      currentPlayer = 0;
      diceRoll = 1; // Reset dice roll
      for (int i = 0; i < playerScores.length; i++) {
        playerScores[i] = 0;
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Ludo Dice Game'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              'Round $currentRound of $totalRounds',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 20),
            Text(
              'Player ${currentPlayer + 1}\'s Turn',
              style: TextStyle(fontSize: 24),
            ),
            SizedBox(height: 20),
            GestureDetector(
              onTap: rollDice,
              child: Image.asset(
                'images/$diceRoll.jpeg',
                height: 100, // Adjust height based on your needs
                width: 100,
              ),
            ),
            SizedBox(height: 20),
            Column(
              children: List.generate(4, (index) {
                return Text(
                  'Player ${index + 1}: ${playerScores[index]}',
                  style: TextStyle(fontSize: 18),
                );
              }),
            ),
          ],
        ),
      ),
    );
  }
}